package PA4.work;
// Name: Xinyu Wu
// USC NetID: xwu26173
// CS 455 PA4
// Fall 2022


/**
 * Score table indicating how much each scrabble letter is worth
 */
public class ScoreTable {

   /**
    * Representation invariant:
    * After initiation, scoreTable.length = 26, each index corresponding to
    * a letter. Each value in the array is in range [1, 10] and is equal
    * to the score of the corresponding letter. Upper and lower-case letter
    * always share the same score.
    */
   private int[] scoreTable;

   /**
    * Create a score table
    */
   public ScoreTable() {
      Character[] score1 = new Character[]{'A','E', 'I', 'O', 'U', 'L', 'N', 'S', 'T', 'R'};
      Character[] score2 = new Character[]{'D', 'G'};
      Character[] score3 = new Character[]{'B', 'C', 'M', 'P'};
      Character[] score4 = new Character[]{'F', 'H', 'V', 'W', 'Y'};
      Character[] score5 = new Character[]{'K'};
      Character[] score8 = new Character[]{'J', 'X'};
      Character[] score10 = new Character[]{'Q', 'Z'};
      int[] scores = new int[]{1, 2, 3, 4, 5, 8, 10};
      Character[][] characterScore = new Character[][]{score1, score2, score3, score4, score5, score8, score10};

      scoreTable = new int[26];
      for (int i = 0; i < scores.length; i++) {
         for (char c : characterScore[i]) {
            scoreTable[c - 'A'] = scores[i];
         }
      }
   }

   /**
    * Get the score of a letter
    * @param c the character given
    * @return the score of the letter
    * PRE: c is a letter [A-Za-z]
    */
   private int getCharScore(Character c) {
      if (c - 'a' < 0) {
         return scoreTable[c-'A'];
      } else {
         return scoreTable[c-'a'];
      }
   }

   /**
    * Get the score of a string
    * @param s the string given
    * @return the total score of letters in the string
    * PRE: s only contains letters [A-Za-z]
    */
   public int getStringScore(String s) {
      int totalScore = 0;
      for (int i = 0; i < s.length(); i++) {
         totalScore += getCharScore(s.charAt(i));
      }
      return totalScore;
   }

}
