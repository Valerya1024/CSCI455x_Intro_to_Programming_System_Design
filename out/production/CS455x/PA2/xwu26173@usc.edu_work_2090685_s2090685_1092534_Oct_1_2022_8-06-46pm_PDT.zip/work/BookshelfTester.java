import java.util.ArrayList;
import java.util.Arrays;

public class BookshelfTester {
   public static void main(String[] args) {
      ArrayList<Integer> arr = new ArrayList<>(Arrays.asList(2,3,4,5,6,7,8,9));
      Bookshelf bookshelf = new Bookshelf(arr);
      System.out.printf("After constructing bookshelf with books 2,3,4,5,6,7,8,9 unit high:\n" +
            "bookshelf: %s\n\n", bookshelf.toString());

      System.out.printf("Test size()\n" +
            "Expected: %d\n" +
            "Result: %d\n" +
            "Passed? %b\n\n", 8, bookshelf.size(), 8==bookshelf.size());

      System.out.printf("Test getHeight()\n" +
            "position = 0\n" +
            "Expected: %d\n" +
            "Result: %d\n" +
            "Passed? %b\n", 2, bookshelf.getHeight(0), 2==bookshelf.getHeight(0));
      System.out.printf("position = 5\n" +
            "Expected: %d\n" +
            "Result: %d\n" +
            "Passed? %b\n", 7, bookshelf.getHeight(5), 7==bookshelf.getHeight(5));
      System.out.printf("position = 7\n" +
            "Expected: %d\n" +
            "Result: %d\n" +
            "Passed? %b\n\n", 9, bookshelf.getHeight(7), 9==bookshelf.getHeight(7));

      System.out.printf("Test isSorted()\n" +
            "Expected: %b\n" +
            "Result: %b\n" +
            "Passed? %b\n\n", true, bookshelf.isSorted(), bookshelf.isSorted()==true);

      bookshelf.addFront(1);
      System.out.printf("After adding a book 1 unit high at the front:\n" +
            "bookshelf: %s\n\n", bookshelf.toString());

      System.out.printf("Test size()\n" +
            "Expected: %d\n" +
            "Result: %d\n" +
            "Passed? %b\n\n", 9, bookshelf.size(), 9==bookshelf.size());

      System.out.printf("Test getHeight()\n" +
            "position = 5\n" +
            "Expected: %d\n" +
            "Result: %d\n" +
            "Passed? %b\n\n", 6, bookshelf.getHeight(5), 6==bookshelf.getHeight(5));

      System.out.printf("Test isSorted()\n" +
            "Expected: %b\n" +
            "Result: %b\n" +
            "Passed? %b\n\n", true, bookshelf.isSorted(), bookshelf.isSorted()==true);

      bookshelf.addLast(3);
      System.out.printf("After adding a book 3 unit high at the back:\n" +
            "bookshelf: %s\n\n", bookshelf.toString());

      System.out.printf("Test size()\n" +
            "Expected: %d\n" +
            "Result: %d\n" +
            "Passed? %b\n\n", 10, bookshelf.size(), 10==bookshelf.size());

      System.out.printf("Test isSorted()\n" +
            "Expected: %b\n" +
            "Result: %b\n" +
            "Passed? %b\n\n", false, bookshelf.isSorted(), bookshelf.isSorted()==false);

      bookshelf.removeLast();
      System.out.printf("After removing a book at the back:\n" +
            "bookshelf: %s\n\n", bookshelf.toString());

      System.out.printf("Test size()\n" +
            "Expected: %d\n" +
            "Result: %d\n" +
            "Passed? %b\n\n", 9, bookshelf.size(), 9==bookshelf.size());

      System.out.printf("Test isSorted()\n" +
            "Expected: %b\n" +
            "Result: %b\n" +
            "Passed? %b\n\n", true, bookshelf.isSorted(), bookshelf.isSorted()==true);
   }
}
