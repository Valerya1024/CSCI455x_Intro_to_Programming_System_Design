import java.util.ArrayList;
import java.util.Arrays;

public class BookshelfTester {
   public static void main(String[] args) {

      ArrayList<Integer> arr = new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9));
      Bookshelf bookshelf = new Bookshelf(arr);
      String testBookshelf = bookshelf.toString();
      String expected = "[1, 2, 3, 4, 5, 6, 7, 8, 9]";
      System.out.printf("After constructing bookshelf with books 1,2,3,4,5,6,7,8,9 unit high:\n" +
            "Expected: %s\n" +
            "Result: %s\n" +
            "Passed? %b\n\n", expected, testBookshelf, testBookshelf.equals(expected));

      bookshelf.addFront(1);
      testBookshelf = bookshelf.toString();
      expected = "[1, 1, 2, 3, 4, 5, 6, 7, 8, 9]";
      System.out.printf("After adding 1 unit high book at the front:\n" +
            "Expected: %s\n" +
            "Result: %s\n" +
            "Passed? %b\n\n", expected, testBookshelf, testBookshelf.equals(expected));

      bookshelf.addLast(10);
      testBookshelf = bookshelf.toString();
      expected = "[1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]";
      System.out.printf("After adding 10 unit high book at the back:\n" +
            "Expected: %s\n" +
            "Result: %s\n" +
            "Passed? %b\n\n", expected, testBookshelf, testBookshelf.equals(expected));

      bookshelf.removeFront();
      testBookshelf = bookshelf.toString();
      expected = "[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]";
      System.out.printf("After removing a book at the front:\n" +
            "Expected: %s\n" +
            "Result: %s\n" +
            "Passed? %b\n\n", expected, testBookshelf, testBookshelf.equals(expected));

      bookshelf.removeLast();
      testBookshelf = bookshelf.toString();
      expected = "[1, 2, 3, 4, 5, 6, 7, 8, 9]";
      System.out.printf("After removing a book at the back:\n" +
            "Expected: %s\n" +
            "Result: %s\n" +
            "Passed? %b\n\n", expected, testBookshelf, testBookshelf.equals(expected));

   }
}
