// Name: Xinyu Wu
// USC NetID: xwu26173
// CSCI455 PA2
// Fall 2022

import java.util.ArrayList;

/**
 * Class BookshelfKeeper 
 *
 * Enables users to perform efficient putPos or pickHeight operation on a bookshelf of books kept in 
 * non-decreasing order by height, with the restriction that single books can only be added 
 * or removed from one of the two *ends* of the bookshelf to complete a higher level pick or put 
 * operation.  Pick or put operations are performed with minimum number of such adds or removes.
 */
public class BookshelfKeeper {

    /**
      Representation invariant:
      bookshelf is not null;
      bookshelf.isSorted() == true;
   */
   
   // instance variables
   private Bookshelf bookshelf; //defines the bookshelf the bookShelfKeeper keeps
   private int totalCalls;
   private int lastCalls;

   /**
    * Creates a BookShelfKeeper object with an empty bookshelf
    */
   public BookshelfKeeper() {
      bookshelf = new Bookshelf();
      totalCalls = 0;
      lastCalls = 0;
      assert isValidBookshelfKeeper();
   }

   /**
    * Creates a BookshelfKeeper object initialized with the given sorted bookshelf.
    * Note: method does not make a defensive copy of the bookshelf.
    *
    * PRE: sortedBookshelf.isSorted() is true.
    */
   public BookshelfKeeper(Bookshelf sortedBookshelf) {
      bookshelf = sortedBookshelf;
      assert isValidBookshelfKeeper();
   }  

   /**
    * Removes a book from the specified position in the bookshelf and keeps bookshelf sorted 
    * after picking up the book.
    * 
    * Returns the number of calls to mutators on the contained bookshelf used to complete this
    * operation. This must be the minimum number to complete the operation.
    * 
    * PRE: 0 <= position < getNumBooks()
    */

   public int pickPos(int position) {
      int pickFromFront = position + 1;
      int pickFromBack = bookshelf.size() - position;
      ArrayList<Integer> removedBooks = new ArrayList<>(); //temporally stores heights of removed books
      lastCalls = 0;
      if (pickFromBack > pickFromFront) {
         for (int i = 0; i < pickFromFront; i++) {
            removedBooks.add(bookshelf.removeFront());
            lastCalls++;
         }
         for (int i = removedBooks.size() - 2; i >= 0; i--) {
            bookshelf.addFront(removedBooks.get(i));
            lastCalls++;
         }
      } else {
         for (int i = 0; i < pickFromBack; i++) {
            removedBooks.add(bookshelf.removeLast());
            lastCalls++;
         }
         for (int i = removedBooks.size() - 2; i >= 0; i--) {
            bookshelf.addLast(removedBooks.get(i));
            lastCalls++;
         }
      }
      totalCalls += lastCalls;
      assert isValidBookshelfKeeper();

      return removedBooks.get(0);
   }

   /**
    * Inserts book with specified height into the shelf.  Keeps the contained bookshelf sorted 
    * after the insertion.
    * 
    * Returns the number of calls to mutators on the contained bookshelf used to complete this
    * operation. This must be the minimum number to complete the operation.
    * 
    * PRE: height > 0
    */
   public int putHeight(int height) {
      int idxFromFront = bisectLeft(height);
      int idxFromBack = bisectRight(height);
      lastCalls = 0;
      ArrayList<Integer> removedBooks = new ArrayList<>(); //temporally stores heights of removed books

      int pickFromFront = idxFromFront;
      int pickFromBack = bookshelf.size() - idxFromBack;

      if (pickFromBack < idxFromFront) {
         for (int i = 0; i < pickFromBack; i++) {
            removedBooks.add(bookshelf.removeLast());
            lastCalls++;
         }
         bookshelf.addLast(height);
         lastCalls++;
         for (int i = removedBooks.size() - 1; i >= 0; i--) {
            bookshelf.addLast(removedBooks.get(i));
            lastCalls++;
         }
      } else {
         for (int i = 0; i < pickFromFront; i++) {
            removedBooks.add(bookshelf.removeFront());
            lastCalls++;
         }
         bookshelf.addFront(height);
         lastCalls++;
         for (int i = removedBooks.size() - 1; i >= 0; i--) {
            bookshelf.addFront(removedBooks.get(i));
            lastCalls++;
         }
      }
      totalCalls += lastCalls;
      assert isValidBookshelfKeeper();

      return lastCalls;
   }

   /**
    * Find out the index where the book should be inserted from back end
    *
    * PRE: sortedBookshelf.isSorted() is true. height > 0
    * @param height  height of the book to be inserted.
    */
   private int bisectRight(int height) {
      int highIdx = bookshelf.size();
      int lowIdx = 0;
      int mid;
      while (lowIdx < highIdx) {
         mid = (lowIdx +highIdx) / 2;
         if (bookshelf.getHeight(mid) > height) {
            highIdx = mid;
         } else {
            lowIdx = mid +1;
         }
      }
      return lowIdx;
   }

   /**
    * Find out the index where the book should be inserted from front end
    *
    * PRE: sortedBookshelf.isSorted() is true. height > 0
    * @param height  height of the book to be inserted.
    */
   private int bisectLeft(int height) {
      int highIdx = bookshelf.size();
      int lowIdx = 0;
      int mid;
      while (lowIdx < highIdx) {
         mid = (lowIdx + highIdx) / 2;
         if (bookshelf.getHeight(mid) < height) {
            lowIdx = mid + 1;
         } else {
            highIdx = mid;
         }
      }
      return lowIdx;
   }

   /**
    * Returns the total number of calls made to mutators on the contained bookshelf
    * so far, i.e., all the ones done to perform all of the pick and put operations
    * that have been requested up to now.
    */
   public int getTotalOperations() {
      return totalCalls;
   }

   /**
    * Returns the number of books on the contained bookshelf.
    */
   public int getNumBooks() {
       return bookshelf.size();
   }

   /**
    * Returns string representation of this BookshelfKeeper. Returns a String containing height
    * of all books present in the bookshelf in the order they are on the bookshelf, followed 
    * by the number of bookshelf mutator calls made to perform the last pick or put operation, 
    * followed by the total number of such calls made since we created this BookshelfKeeper.
    * 
    * Example return string showing required format: “[1, 3, 5, 7, 33] 4 10”
    * 
    */
   public String toString() {
      return bookshelf.toString() + " " + lastCalls + " " + totalCalls;
      
   }

   /**
    * Returns true if the BookshelfKeeper data is in a valid state.
    * (See representation invariant comment for details.)
    */
   private boolean isValidBookshelfKeeper() {
      if (bookshelf == null) {
         return false;
      }
      if (!bookshelf.isSorted()){
         return false;
      }
      return true;

   }


}
