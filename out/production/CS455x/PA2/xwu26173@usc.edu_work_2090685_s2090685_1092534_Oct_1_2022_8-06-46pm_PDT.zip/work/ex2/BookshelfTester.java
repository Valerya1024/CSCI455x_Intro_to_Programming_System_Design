import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class BookshelfTester {
   public static void main(String[] args) {

      Bookshelf emptyBookshelf = new Bookshelf();
      String testEmptyBookshelf = emptyBookshelf.toString();
      System.out.printf("After constructing empty bookshelf:\n" +
            "Expected: []\n" +
            "Result: %s\n" +
            "Passed? %b\n\n", testEmptyBookshelf, testEmptyBookshelf.equals("[]"));

      ArrayList<Integer> arr1 = new ArrayList<>(Arrays.asList(1, 5, 8));
      Bookshelf bookshelf1 = new Bookshelf(arr1);
      String testBookshelf1 = bookshelf1.toString();
      String expected1 = "[1, 5, 8]";
      System.out.printf("After constructing bookshelf with books 1, 5 , 8 unit high:\n" +
            "Expected: %s\n" +
            "Result: %s\n" +
            "Passed? %b\n\n", expected1, testBookshelf1, testBookshelf1.equals(expected1));

      ArrayList<Integer> arr2 = new ArrayList<>(Collections.nCopies(10,1));
      Bookshelf bookshelf2 = new Bookshelf(arr2);
      String testBookshelf2 = bookshelf2.toString();
      String expected2 = "[1, 1, 1, 1, 1, 1, 1, 1, 1, 1]";
      System.out.printf("After constructing bookshelf with 10 books 1 unit high:\n" +
            "Expected: %s\n" +
            "Result: %s\n" +
            "Passed? %b\n\n", expected2, testBookshelf2, testBookshelf2.equals(expected2));

      ArrayList<Integer> arr3 = new ArrayList<>(Arrays.asList(2147483647));
      Bookshelf bookshelf3 = new Bookshelf(arr3);
      String testBookshelf3 = bookshelf3.toString();
      String expected3 = "[2147483647]";
      System.out.printf("After constructing bookshelf with a book 2147483647 unit high:\n" +
            "Expected: %s\n" +
            "Result: %s\n" +
            "Passed? %b\n\n", expected3, testBookshelf3, testBookshelf3.equals(expected3));
   }
}
