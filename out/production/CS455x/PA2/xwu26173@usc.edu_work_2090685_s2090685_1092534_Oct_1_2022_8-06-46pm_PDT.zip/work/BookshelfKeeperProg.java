// Name: Xinyu Wu
// USC NetID: xwu26173
// CSCI455 PA2
// Fall 2022

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class BookshelfKeeperProg
 *
 * This program allows the user to perform a series of pickPos and putHeight operations on
 * a bookshelf in an interactive mode.
 * The user should first input a series of positive integers arranged in non-decreasing order
 * representing the height of books to initialize bookshelf and bookshelfKeeper. Then
 * users could manipulate the bookshelf with user commands called pick and put. Users could
 * type end to exit this program.
 *
 */
public class BookshelfKeeperProg {
   public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      //define & initialize bookshelfKeeper for users to perform operations on
      BookshelfKeeper bookshelfKeeper = initialize(scanner);
      operate(scanner, bookshelfKeeper);
   }

   /**
    * Initialize bookshelf bookshelfKeeper. If user input contains errors, prints error message and
    * return null.
    *
    */
   private static BookshelfKeeper initialize(Scanner scanner) {
      BookshelfKeeper bookshelfKeeper; //defines the bookshelfKeeper to be initialized
      ArrayList<Integer> books = new ArrayList<>(); //temporally stores the heights of books from user input

      System.out.println("Please enter initial arrangement of books followed by newline:");
      String line = scanner.nextLine();

      Scanner lineScanner = new Scanner(line);
      while (lineScanner.hasNextInt()) {
         int height = lineScanner.nextInt();
         if (height <= 0) {
            System.out.println("ERROR: Height of a book must be positive.\nExiting Program.");
            return null;
         }
         books.add(height);
      }
      Bookshelf bookshelf = new Bookshelf(books); //define & initializes a bookshelf containing sorted books
      if (!bookshelf.isSorted()) {
         System.out.println("ERROR: Heights must be specified in non-decreasing order.\nExiting Program.");
         return null;
      }
      bookshelfKeeper = new BookshelfKeeper(bookshelf);

      System.out.println(bookshelfKeeper.toString());
      return bookshelfKeeper;
   }

   /**
    * Reads user input command (put, pick or end) to manipulate bookshelf. If input contains errors,
    * prints error message and end program. If bookshelf is null, end program.
    *
    */
   private static void operate(Scanner scanner, BookshelfKeeper bookshelfKeeper) {
      if (bookshelfKeeper == null) {
         return;
      }
      System.out.println("Type pick <index> or put <height> followed by newline. Type end to exit.");
      while (true) {
         String operation = scanner.next().trim();
         switch (operation) {
            case "end":
               System.out.println("Exiting Program.");
               return;
            case "put":
               int height = scanner.nextInt();
               if (height < 1) {
                  System.out.println("ERROR: Height of a book must be positive.\nExiting Program.");
                  return;
               }
               bookshelfKeeper.putHeight(height);
               System.out.println(bookshelfKeeper.toString());
               break;
            case "pick":
               int index = scanner.nextInt();
               if (index < 0 || index >= bookshelfKeeper.getNumBooks()) {
                  System.out.println("ERROR: Entered pick operation is invalid on this shelf.\nExiting Program.");
                  return;
               }
               bookshelfKeeper.pickPos(index);
               System.out.println(bookshelfKeeper.toString());
               break;
            default:
               System.out.println("ERROR: Invalid command. Valid commands are pick, put, or end. \nExiting Program.");
               return;
         }
      }
   }
}
