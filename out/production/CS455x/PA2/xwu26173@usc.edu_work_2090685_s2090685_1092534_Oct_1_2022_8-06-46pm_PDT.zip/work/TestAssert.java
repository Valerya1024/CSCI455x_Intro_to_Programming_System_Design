import java.util.ArrayList;
import java.util.Arrays;

public class TestAssert {
   public static void main(String[] args) {
      ArrayList<Integer> arrSorted = new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9));
      Bookshelf bookshelfSorted = new Bookshelf(arrSorted);
      System.out.printf("Constructing bookshelf with books 1,2,3,4,5,6,7,8,9 unit high:\n" +
            "bookshelf: %s\n\n", bookshelfSorted.toString());

      System.out.println("Constructing bookshelf with books 0,10,3,19 unit high:");
      ArrayList<Integer> arrWith0 = new ArrayList<>(Arrays.asList(0,10,3,19));
      Bookshelf bookshelfWith0 = new Bookshelf(arrWith0);
      System.out.printf("bookshelf: %s\n\n", bookshelfWith0.toString());
   }
}
