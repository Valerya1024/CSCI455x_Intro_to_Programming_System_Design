package lab3;

import lab3.Change;

public class CashReg
{

    private int purchase;
    private int payment;
    private int change;

    /**
     Constructs a cash register with no money in it.
     */
    public CashReg()
    {
        purchase = 0;
        payment = 0;
        change = 0;
    }

    /**
     Records the purchase price of an item.
     @param amount the price of the purchased item
     */
    public void recordPurchase(double amount)
    {
        purchase = purchase + (int) Math.round(amount*100);
    }

    /**
     Gets total of all purchases made.
     */
    public double getTotal() {
        return (double) purchase / 100;
    };

    public void receivePayment(Change money)
    {
        payment = money.totalValue();
    }

    /**
     Computes the change due and resets the machine for the next customer.
     @return the change due to the customer
     */
    public Change giveChange()
    {
        change = payment - purchase;
        purchase = 0;
        payment = 0;
        int dollars = giveDollars();
        int quarters = giveQuarters();
        int dimes = giveDimes();
        int nickels = giveNickels();
        int pennies = givePennies();
        Change money = new Change(dollars, quarters, dimes, nickels, pennies);
        return money;
    }

    private int giveDollars(){
        int dollars = this.change / Change.DOLLAR_VALUE;
        this.change = this.change % Change.DOLLAR_VALUE;
        return dollars;
    }

    private int giveQuarters(){
        int quarters = this.change / Change.QUARTER_VALUE;
        this.change = this.change % Change.QUARTER_VALUE;
        return quarters;
    }

    private int giveDimes(){
        int dimes = this.change / Change.DIME_VALUE;
        this.change = this.change % Change.DIME_VALUE;
        return dimes;
    }

    private int giveNickels(){
        int nickels = this.change / Change.NICKEL_VALUE;
        this.change = this.change % Change.NICKEL_VALUE;
        return nickels;
    }

    private int givePennies(){
        int pennies = this.change;
        this.change = 0;
        return pennies;
    }

}
