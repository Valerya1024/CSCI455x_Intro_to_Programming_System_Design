package lab8.work;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**
   This program reads a file containing numbers and analyzes its contents.
   If the file doesn't exist or contains strings that are not numbers, an
   error message is displayed.
*/
public class DataAnalyzer
{
   public static void main(String[] args)
   {
      Scanner in = new Scanner(System.in);
      DataSetReader reader = new DataSetReader();
      
      boolean done = false;
      while (!done) 
      {
         try 
         {
            System.out.println("Please enter the file name: ");
            String filename = in.next();
            
            double[] data = reader.readFile(filename);
            double sum = 0;
            for (double d : data) { sum = sum + d; }
            System.out.println("The sum is " + sum);
            done = true;
         }
         catch (FileNotFoundException exception)
         {
            System.out.println(exception.getMessage()); // Part 2: include the file name given by the the user.
         }
         catch (BadDataException exception)
         {
            System.out.println("Bad data: " + exception.getMessage());
            done = true;  // Part 1: exit the program if it found any problems with the file format.
         }
         catch (IOException exception)
         {
            exception.printStackTrace();
         }
      }
   }
}
