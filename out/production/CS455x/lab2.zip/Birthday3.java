package lab2;

import java.time.LocalDate;
import java.util.Scanner;

//Q2
public class Birthday3 {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.print("Enter your birth month [1..12]: ");
        int month = in.nextInt();
        System.out.print("Enter your birth day of month: ");
        int day = in.nextInt();
        System.out.print("Enter your birth year [4-digit year]: ");
        int year = in.nextInt();
        LocalDate current = LocalDate.now();
        LocalDate birthday = LocalDate.of(current.getYear(),month,day);
        if (current.isBefore(birthday)) {
            System.out.println("Your birthday has not yet happened this year.");
        } else {
            System.out.println("Your birthday has already happened this year.");
        }
    }
}

/* Question 3.1 Describe two compile errors that you got and their fixes while developing this code.
I forgot to add ";" after one of the command and got "';' expected". I fixed it by adding the semicolon.

Question 3.2 Devise three test cases (not the one above) for which you and the TA already know the answer,
to help verify that your code is working correctly. Describe these test cases and the expected results in the README.
Then try out your test cases to help verify your program works properly.

Test 1
9/15/2000
Your birthday has not yet happened this year.

Test 2
3/12/2000
Your birthday has already happened this year.

Test 3
8/31/2011
Your birthday has already happened this year.

*/