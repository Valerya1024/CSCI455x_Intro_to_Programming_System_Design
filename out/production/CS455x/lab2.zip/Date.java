package lab2;

import java.time.LocalDate;

//Q2
public class Date {
    public static void main(String[] args){
        LocalDate myDate = LocalDate.of(1995,1,20);
        System.out.printf("%d/%d/%d\n",myDate.getMonthValue(),myDate.getDayOfMonth(),myDate.getYear());
        LocalDate later = myDate.plusDays(20);
        System.out.printf("%d/%d/%d\n",later.getMonthValue(),later.getDayOfMonth(),later.getYear());
    }
}
