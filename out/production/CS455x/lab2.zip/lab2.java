package lab2;
//Q1.0 Qichen Wang
//Q1.1
import java.time.LocalDate;

public class lab2 {
    public static void main(String[] args){
        //Q1.2
        LocalDate myDate = LocalDate.of(1995,1,20);
        //Q1.3
        System.out.printf("%d/%d/%d\n",myDate.getMonthValue(),myDate.getDayOfMonth(),myDate.getYear());
        //Q1.4
        LocalDate later = myDate.plusDays(20);
        //Q1.5
        myDate = later;
    }
}
