package lab2;

import java.time.LocalDate;
import java.util.Scanner;

//Q4
public class Birthday {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.print("Enter your birth month [1..12]: ");
        int month = in.nextInt();
        System.out.print("Enter your birth day of month: ");
        int day = in.nextInt();
        System.out.print("Enter your birth year [4-digit year]: ");
        int year = in.nextInt();
        LocalDate current = LocalDate.now();
        LocalDate birthday = LocalDate.of(current.getYear(),month,day);

        int age = current.getYear() - year;
        if (current.isBefore(birthday)) {
            System.out.println("Your birthday has not yet happened this year.");
            age -= 1;
        } else if (current.isEqual(birthday)){
            System.out.println("Happy birthday!");
        } else {
            System.out.println("Your birthday has already happened this year.");
        }
        System.out.printf("You're %d years old.", age);
    }
}
