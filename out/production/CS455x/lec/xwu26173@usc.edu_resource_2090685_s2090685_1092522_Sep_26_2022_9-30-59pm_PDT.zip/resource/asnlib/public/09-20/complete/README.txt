Complete code for Names.java and NamesTester.java.
This version of the code is slightly different in some places than 
the version of the code we developed in lecture.
