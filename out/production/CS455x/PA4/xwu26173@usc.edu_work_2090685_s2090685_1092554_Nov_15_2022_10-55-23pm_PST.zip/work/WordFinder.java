//package PA4.work;
// Name: Xinyu Wu
// USC NetID: xwu26173
// CS 455 PA4
// Fall 2022

import java.io.FileNotFoundException;
import java.util.*;

/**
 * Construct a Scrabble rack with given letter, and finds all legal words in given or
 * default dictionary that can be formed from the letters on that rack.
 */
public class WordFinder {

   /**
    * Constant: rack is word of length two or more
    */
   public static final int MIN_RACK_LENGTH = 2;

   /**
    * to compile and run this program, run command line command:
    * javac *.java
    * java WordFinder [filename]
    * The filename argument is the path of dictionary file and is optional.
    * When Rack? is printed, user can type in a rack or type "." to quit.
    */
   public static void main(String[] args) {
      String filename;
      if (args.length == 0) {
         filename = "sowpods.txt";
      } else {
         filename = args[0];
      }
      try {
         ScoreTable scoreTable = new ScoreTable();
         AnagramDictionary anagramDictionary = new AnagramDictionary(filename);
         Scanner in = new Scanner(System.in);
         boolean endProgram = false;
         System.out.println("Type . to quit.");
         while (!endProgram) {
            System.out.print("Rack? ");
            String rackLetters = in.next();
            int periodIdx = rackLetters.indexOf('.');
            if (periodIdx >= 0) {
               endProgram = true;
               rackLetters = rackLetters.substring(0,periodIdx);
            }
            findWord(rackLetters, scoreTable, anagramDictionary);
         }
      } catch (FileNotFoundException e) {
         System.out.println(e.getMessage() + "\nExiting program.");
      } catch (IllegalDictionaryException e) {
         System.out.println(e.getMessage() + "\nExiting program.");
      }
   }

   /**
    * Helper method findWord: first delete any non-letter character in the user inputted
    * string, if the remaining string has more than 2 letters, construct a rack with the
    * remaining string, finds all legal words that can be formed from the letters on that
    * rack with anagramDictionary, calculate each word's score with scoreTable and sort
    * the words according to scores.
    * @param word the user inputted rack string
    * @param scoreTable score table indicating how much each scrabble letter is worth
    * @param anagramDictionary dictionary of all anagram sets
    */
   private static void findWord(String word, ScoreTable scoreTable, AnagramDictionary anagramDictionary) {
      word = word.replaceAll("[^A-Za-z]","");
      if (word.length() >= MIN_RACK_LENGTH) {
         Rack rack = new Rack(word);
         ArrayList<String> subsets = rack.getAllSubsets();
         Map<String, Integer> result = new HashMap<>();
         for (String subset : subsets) {
            int score = scoreTable.getStringScore(subset);
            ArrayList<String> anagrams = anagramDictionary.getAnagramsOf(subset);
            for (String anagram : anagrams) {
               result.put(anagram, score);
            }
         }
         ArrayList<Map.Entry<String, Integer>> sortResult = new ArrayList<>();
         sortResult.addAll(result.entrySet());
         Collections.sort(sortResult, new MapValueComparator());
         printWord(sortResult, word);
      }
   }

   /**
    * Helper method printWord: first print how many words can be made from the rack.
    * If there are more than 0 word, print "All of the words with their scores (sorted
    * by score):" followed by score: word pairs.
    * @param map the map containing word score pairs
    * @param word the user inputted rack string
    */
   private static void printWord(ArrayList<Map.Entry<String, Integer>> map, String word) {
      System.out.println("We can make " + map.size() + " words from \"" + word + "\"");
      if (map.size()>0){
         System.out.println("All of the words with their scores (sorted by score):");
      }
      for (Map.Entry<String, Integer> entry : map) {
         System.out.println(entry.getValue()+": "+entry.getKey());
      }
   }

}

/**
 * Implements Comparator class, used to compare Map entries when sorting
 */
class MapValueComparator implements Comparator<Map.Entry<String, Integer>> {
   @Override
   /**
    * Compare words in decreasing order by score. If words have the same scrabble score,
    * compare them in alphabetical order
    * @param o1 the map entry to compare
    * @param o2 the map entry to compare
    * @return negative int if o1 comes before o2 when sorting, positive if o2 comes first
    */
   public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
      int diffScore = o2.getValue() - o1.getValue();
      if (diffScore != 0) {
         return diffScore;
      } else {
         return o1.getKey().compareTo(o2.getKey());
      }
   }
}
