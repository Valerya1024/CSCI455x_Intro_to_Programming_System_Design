//package PA4.work;
// Name: Xinyu Wu
// USC NetID: xwu26173
// CS 455 PA4
// Fall 2022

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;


/**
   A dictionary of all anagram sets. 
   Note: the processing is case-sensitive; so if the dictionary has all lower
   case words, you will likely want any string you test to have all lower case
   letters too, and likewise if the dictionary words are all upper case.
 */
public class AnagramDictionary {

   /**
    * Representation invariant
    * length of key of the anagramDictionary >= 2;
    * key only contains letters [A-Za-z];
    * letters in the key is sorted in alphabetical order;
    * if anagramDictionary.get(string) != null, then size of the set >= 1,
    * words in the set are anagrams of the key
    */
   private Map<String, Set<String>> anagramDictionary;


   /**
    * Create an anagram dictionary from the list of words given in the file
    * indicated by fileName.
    * @param fileName the name of the file to read from
    * @throws FileNotFoundException      if the file is not found
    * @throws IllegalDictionaryException if the dictionary has any duplicate words
    */
   public AnagramDictionary(String fileName) throws FileNotFoundException, IllegalDictionaryException {
      try {
         Scanner scanner = new Scanner(new File(fileName));
         this.anagramDictionary = new HashMap<>();
         while (scanner.hasNext()) {
            String word = scanner.next();
            String anagram = sortString(word);
            Set<String> anagramList = anagramDictionary.get(anagram);
            if (anagramList == null) {
               anagramList = new HashSet<>();
               anagramList.add(word);
               anagramDictionary.put(anagram, anagramList);
            } else {
               boolean existed = anagramList.add(word);
               if (!existed) {
                  throw new IllegalDictionaryException("ERROR: Illegal dictionary: dictionary file has a duplicate word: " + word);
               }
            }
         }
      } catch (FileNotFoundException e) {
         throw new FileNotFoundException("ERROR: Dictionary file \"" + fileName + "\" does not exist.");
      }
   }


   /**
    * Get all anagrams of the given string. This method is case-sensitive.
    * E.g. "CARE" and "race" would not be recognized as anagrams.
    *
    * @param string string to process
    * @return a list of the anagrams of string
    * PRE: letters in string is sorted in alphabetical order
    */
   public ArrayList<String> getAnagramsOf(String string) {
      ArrayList<String> list = new ArrayList<>();
      Set<String> set = anagramDictionary.get(string);
      if (set != null) {
         list.addAll(set);
      }
      return list;
   }

   /**
    * Sort the letters in the given String in alphabetical order. This method is
    * case-sensitive. Upper-case characters will appear before lower-case letters.
    * @param string string to process
    * @return the sorted string
    */
   private String sortString(String string) {
      String[] charArray = string.split("");
      Arrays.sort(charArray);
      return String.join("", charArray);
   }
}
