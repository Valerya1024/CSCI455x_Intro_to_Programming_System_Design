package PA3.work;
// Name: Xinyu Wu
// USC NetID: xwu26173
// CS 455 PA3
// Fall 2022


/**
  VisibleField class
  This is the data that's being displayed at any one point in the game (i.e., visible field, because it's what the
  user can see about the minefield). Client can call getStatus(row, col) for any square.
  It actually has data about the whole current state of the game, including  
  the underlying mine field (getMineField()).  Other accessors related to game status: numMinesLeft(), isGameOver().
  It also has mutators related to actions the player could do (resetGameDisplay(), cycleGuess(), uncover()),
  and changes the game state accordingly.
  
  It, along with the MineField (accessible in mineField instance variable), forms
  the Model for the game application, whereas GameBoardPanel is the View and Controller in the MVC design pattern.
  It contains the MineField that it's partially displaying.  That MineField can be accessed (or modified) from 
  outside this class via the getMineField accessor.  
 */
public class VisibleField {
   // ----------------------------------------------------------   
   // The following public constants (plus numbers mentioned in comments below) are the possible states of one
   // location (a "square") in the visible field (all are values that can be returned by public method 
   // getStatus(row, col)).
   
   // The following are the covered states (all negative values):
   public static final int COVERED = -1;   // initial value of all squares
   public static final int MINE_GUESS = -2;
   public static final int QUESTION = -3;

   // The following are the uncovered states (all non-negative values):
   
   // values in the range [0,8] corresponds to number of mines adjacent to this opened square
   
   public static final int MINE = 9;      // this loc is a mine that hasn't been guessed already (end of losing game)
   public static final int INCORRECT_GUESS = 10;  // is displayed a specific way at the end of losing game
   public static final int EXPLODED_MINE = 11;   // the one you uncovered by mistake (that caused you to lose)
   // ----------------------------------------------------------   
  
   // <put instance variables here>
   /**
    Representation invariant:
    mineField and field are not null;
    0 <= numGuesses <= numRows*numCols;
    0 <= numUncovered <= mineField.numRows()*mineField.numCols() - mineField.numMines();
    */
   private MineField mineField;
   private int[][] field;
   private int numGuesses; //number of guesses made
   private int numUncovered;
   private boolean isGameOver;

   

   /**
      Create a visible field that has the given underlying mineField.
      The initial state will have all the locations covered, no mines guessed, and the game
      not over.
      @param mineField  the minefield to use for for this VisibleField
    */
   public VisibleField(MineField mineField) {
      this.mineField = mineField;
      field = new int[mineField.numRows()][mineField.numCols()];
      resetGameDisplay();
   }
   
   
   /**
      Reset the object to its initial state (see constructor comments), using the same underlying
      MineField. 
   */
   public void resetGameDisplay() {
      numGuesses = 0;
      numUncovered = 0;
      isGameOver = false;
      for (int i = 0; i < getMineField().numRows(); i++) {
         for (int j = 0; j < getMineField().numCols(); j++) {
            field[i][j] = COVERED;
         }
      }
   }
  
   
   /**
      Returns a reference to the mineField that this VisibleField "covers"
      @return the minefield
    */
   public MineField getMineField() {
      return mineField;
   }
   
   
   /**
      Returns the visible status of the square indicated.
      @param row  row of the square
      @param col  col of the square
      @return the status of the square at location (row, col).  See the public constants at the beginning of the class
      for the possible values that may be returned, and their meanings.
      PRE: getMineField().inRange(row, col)
    */
   public int getStatus(int row, int col) {
      return field[row][col];
   }

   
   /**
      Returns the the number of mines left to guess.  This has nothing to do with whether the mines guessed are correct
      or not.  Just gives the user an indication of how many more mines the user might want to guess.  This value will
      be negative if they have guessed more than the number of mines in the minefield.     
      @return the number of mines left to guess.
    */
   public int numMinesLeft() {
      return mineField.numMines()-numGuesses;

   }
 
   
   /**
      Cycles through covered states for a square, updating number of guesses as necessary.  Call on a COVERED square
      changes its status to MINE_GUESS; call on a MINE_GUESS square changes it to QUESTION;  call on a QUESTION square
      changes it to COVERED again; call on an uncovered square has no effect.  
      @param row  row of the square
      @param col  col of the square
      PRE: getMineField().inRange(row, col)
    */
   public void cycleGuess(int row, int col) {
      if (getStatus(row,col) == COVERED) {
         field[row][col] = MINE_GUESS;
         numGuesses++;
      } else if (getStatus(row,col) == MINE_GUESS) {
         field[row][col] = QUESTION;
         numGuesses--;
      } else if (getStatus(row,col) == QUESTION) {
         field[row][col] = COVERED;
      }
   }

   
   /**
      Uncovers this square and returns false iff you uncover a mine here.
      If the square wasn't a mine or adjacent to a mine it also uncovers all the squares in 
      the neighboring area that are also not next to any mines, possibly uncovering a large region.
      Any mine-adjacent squares you reach will also be uncovered, and form 
      (possibly along with parts of the edge of the whole field) the boundary of this region.
      Does not uncover, or keep searching through, squares that have the status MINE_GUESS. 
      Note: this action may cause the game to end: either in a win (opened all the non-mine squares)
      or a loss (opened a mine).
      @param row  of the square
      @param col  of the square
      @return false   iff you uncover a mine at (row, col)
      PRE: getMineField().inRange(row, col)
    */
   public boolean uncover(int row, int col) {
      if (mineField.hasMine(row,col)) {
         lose(row,col);
         return false;
      } else {
         openArea(row,col);
         if (numUncovered == mineField.numCols()*mineField.numRows() - mineField.numMines()) {
            win();
         }
         return true;
      }
   }
 
   
   /**
      Returns whether the game is over.
      (Note: This is not a mutator.)
      @return whether game has ended
    */
   public boolean isGameOver() {
      return isGameOver;
   }
 
   
   /**
      Returns whether this square has been uncovered.  (i.e., is in any one of the uncovered states, 
      vs. any one of the covered states).
      @param row of the square
      @param col of the square
      @return whether the square is uncovered
      PRE: getMineField().inRange(row, col)
    */
   public boolean isUncovered(int row, int col) {
      return getStatus(row, col) >= 0;
   }
   
 
   // <put private methods here>
   /**
    Opens a square if it has no mine and is not MINE_GUESS. If it has no adjacent mines, recursively
    opens all the squares in that region that aren't adjacent to mines until it gets to the boundary
    of the field, or squares that are adjacent to other mines.
    @param row of the square to open
    @param col of the square to open
    PRE: getMineField().inRange(row, col); getMineField().hasMine(row, col) == false;
    */
   private void openArea(int row, int col) {
      if (!isUncovered(row,col) && getStatus(row,col) != MINE_GUESS) {
         int numAdjacentMines = getMineField().numAdjacentMines(row,col);
         field[row][col] = numAdjacentMines;
         numUncovered++;
         if (numAdjacentMines == 0) {
            for (int i = row - 1; i <= row + 1; i++) {
               for (int j = col - 1; j <= col + 1; j++) {
                  if (!(row == i && col == j) && getMineField().inRange(i, j)) { //8-way connectivity
                     openArea(i, j);
                  }
               }
            }
         }
      }
   }

   /**
    When a player opens a mine location, that mine explodes, and they lose the game. The exploded mine is shown by
    a red square. Any previously made incorrect guesses are shown with an X though them, the correctly guessed
    mine locations are still shown as guesses, and the other unopened mines are shown as "mines"
    @param row of the square with exploded mine
    @param col of the square with exploded mine
    PRE: getMineField().inRange(row, col); getMineField().hasMine(row, col)
    */
   private void lose(int row, int col) {
      isGameOver = true;
      for (int i = 0; i < getMineField().numRows(); i++) {
         for (int j = 0; j < getMineField().numCols(); j++) {
            if (getStatus(i,j) == MINE_GUESS && !getMineField().hasMine(i,j)) {
               field[i][j] = INCORRECT_GUESS;
            } else if (getStatus(i,j) != MINE_GUESS && getMineField().hasMine(i,j)) {
               field[i][j] = MINE;
            }
         }
      }
      field[row][col] = EXPLODED_MINE;
   }

   /**
    Winning game display. The field display changes to show where the other mines are (it shows them as guesses, in
    yellow)
    PRE: all of the non-mine locations are opened
    */
   private void win() {
      isGameOver = true;
      for (int i = 0; i < getMineField().numRows(); i++) {
         for (int j = 0; j < getMineField().numCols(); j++) {
            if (!isUncovered(i,j)) {
               field[i][j] = MINE_GUESS;
            }
         }
      }
   }


}
