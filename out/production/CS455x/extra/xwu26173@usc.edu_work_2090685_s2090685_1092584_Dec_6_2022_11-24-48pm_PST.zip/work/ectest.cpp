/*  Name: Xinyu Wu
 *  USC NetID: xwu26173
 *  CS 455 Fall 2022
 *  Extra credit assignment
 *
 *  ectest.cpp
 *
 *  a non-interactive test program to test the functions described in ecListFuncs.h
 *
 *    to run it use the command:   ectest
 *
 *  Note: this uses separate compilation.  You put your list code ecListFuncs.cpp
 *  Code in this file should call those functions.
 */


#include <iostream>
#include <string>

// for istringstream used in buildList (defined below)
#include <sstream>

#include "ecListFuncs.h"

using namespace std;


// You may use the following two utility functions that will make it easier to
// test your list functions on hard-coded list data and compare it to expected
// output:
// (function definitions for them appear at the bottom of this file)


/*
 * listToString
 *
 * PRE: list is a well-formed list.
 *
 * converts the list to a string form that has the following format shown by example.
 * the list is unchanged by the function.
 *
 *   string format:
 *
 *   "()"        an empty list
 *   "(3)        a list with one element, 3
 *   "(3 4 5)"   a list with multiple elements: 3 followed by 4 followed by 5
 *
 */
string listToString(ListType list);


/*
 * buildList
 * 
 * PRE: listString only contains numbers (valid integer format) and spaces
 *
 * creates and returns a linked list from a string of space separated numbers
 * 
 *
 * Examples:
 *  listString         return value of buildList(listString)
 *
 *    ""               ()
 *    "-32"            (-32)
 *    "     -32   "    (-32)
 *    "1 3 2"          (1 3 2)
 *    "  1 3 2"        (1 3 2)
 *
 */
ListType buildList(const string & listString);

void numAdjDupesTester(string input, int expect);

void removeDivTester(string input, int k, string expect);

void splitAtLocTester(string input, int index, string expect1, string expect2, string expect3 );


int main ()
{
   cout << "Test numAdjDupes()" << endl << endl;

   numAdjDupesTester("", 0);
   numAdjDupesTester("2 8 3", 0);
   numAdjDupesTester("4 4 7 3", 1);
   numAdjDupesTester("-2 -1 0 1 2 3 4 5 6", 0);
   numAdjDupesTester("-2 -2 0 0 2 2 4 4 6 6", 5);
   numAdjDupesTester("1 1 1 1 1 1 1 1 1 1 1", 1);
   numAdjDupesTester("5 5 7 5 5 5 5",2);
   numAdjDupesTester("5 7 5 7",0);
   numAdjDupesTester("5 5 5 3 3 3 4 4 4 4",3);

   cout << "Test removeDiv()" << endl << endl;
   removeDivTester("", 3, "()");
   removeDivTester("7 10", 3, "(7 10)");
   removeDivTester("24 12 6 9", 4, "(6 9)");
   removeDivTester("24 12 6 9", 3, "()");
   removeDivTester("3 2 8 4 7", 2, "(3 7)");
   removeDivTester("1 2 3 4 5", 1, "()");
   removeDivTester("1 2 3 4 5 6 7 8 9", 2, "(1 3 5 7 9)");
   removeDivTester("-1 -2 -3 -4 -5 -6 -7 -8 -9", 3, "(-1 -2 -4 -5 -7 -8)");
   
   cout << "Test splitAtLoc()" << endl << endl;
   splitAtLocTester("7 4 4 3 9", 2, "(7 4)", "(3 9)", "()");
   splitAtLocTester("7 4 2 3 9", 0, "()", "(4 2 3 9)", "()");
   splitAtLocTester("1 2 3 3 2", 4, "(1 2 3 3)", "()", "()");
   splitAtLocTester("", 3, "()", "()", "()");
   splitAtLocTester("8 2 5", 2, "(8 2)", "()", "()");
   splitAtLocTester("8 2 5", 3, "(8 2 5)", "()", "()");
   splitAtLocTester("8 2 5", -3, "()", "(8 2 5)", "()");
   splitAtLocTester("3", 0, "()", "()", "()");
   splitAtLocTester("3 5", 0, "()", "(5)", "()");
   splitAtLocTester("3 5", 1, "(3)", "()", "()");
   splitAtLocTester("1 2 3 4 5 6 7 8 9", -1, "()", "(1 2 3 4 5 6 7 8 9)", "()");
   splitAtLocTester("-3 -2 -1 0 1 2 3 4", 0, "()", "(-2 -1 0 1 2 3 4)", "()");
   splitAtLocTester("9 8 7 6 5 4 3 2 1 0", 1, "(9)", "(7 6 5 4 3 2 1 0)", "()");
   splitAtLocTester("9 8 7 6 5 4 3 2 1 0", 8, "(9 8 7 6 5 4 3 2)", "(0)", "()");
   splitAtLocTester("-3 -2 -1 0 1 2 3 4", 7, "(-3 -2 -1 0 1 2 3)", "()", "()");
   splitAtLocTester("-3 -2 -1 0 1 2 3 4", 8, "(-3 -2 -1 0 1 2 3 4)", "()", "()");
   return 0;
}


/*********************************************************
 * Utility function definitions
 *
 */
string listToString(ListType list) {

   string listString = "(";

   if (list == NULL) {
      listString += ")";
      return listString;
   }

   Node *p = list;
   while (p->next != NULL) {
      listString += to_string(p->data) + " ";
      p = p->next;
   }

   // print last one with no trailing space
   listString += to_string(p->data) + ")";

   return listString;

}   


ListType buildList(const string & listString) {

   ListType nums = NULL;

   istringstream istr(listString);  // similar to a Java Scanner over a String

   int num;

   if (istr >> num) { // is there one value there?
      nums = new Node(num);
   }
   else {
      return NULL;
   }

   Node *last = nums;

   while (istr >> num) { 
      last->next = new Node(num);
      last = last->next;
   }

   return nums;
}

void numAdjDupesTester(string input, int expect) {
   ListType list = buildList(input);
   int res = numAdjDupes(list);
   string pass = "FAILED";
   if (res==expect) {
      pass = "passed";
   }
   cout << "Input: " << input << " \nOutput: " << res << " \nExpected: " << expect << " \nPass: " << pass << endl << endl;
}

void removeDivTester(string input, int k, string expect) {
   ListType list = buildList(input);
   removeDiv(list, k);
   string res = listToString(list);
   string pass = "FAILED";
   if (res==expect) {
      pass = "passed";
   }
   cout << "Input: list " << input << " k: " << k << "\nOutput: " << res << " \nExpected: " << expect << " \nPass: " << pass << endl << endl;
}

void splitAtLocTester(string input, int index, string expect1, string expect2, string expect3 ) {
   ListType list = buildList(input);
   ListType a = NULL;
   ListType b = NULL;
   splitAtLoc(list, index, a, b);
   string res1 = listToString(a);
   string res2 = listToString(b);
   string pass = "FAILED";
   if (res1==expect1 && res2==expect2 && listToString(list)==expect3) {
      pass = "passed";
   }
   cout << "Input: list " << input << " index: " << index << " \nOutput: a " << res1 << "; b " << res2 << "; list " << listToString(list) << " \nExpected: a " << expect1  << "; b " << expect2 << "; list " << expect3 << " \nPass: " << pass << endl << endl;

}