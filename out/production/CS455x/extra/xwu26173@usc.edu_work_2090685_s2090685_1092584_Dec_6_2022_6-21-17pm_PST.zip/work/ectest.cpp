/*  Name: Xinyu Wu
 *  USC NetID: xwu26173
 *  CS 455 Fall 2022
 *  Extra credit assignment
 *
 *  ectest.cpp
 *
 *  a non-interactive test program to test the functions described in ecListFuncs.h
 *
 *    to run it use the command:   ectest
 *
 *  Note: this uses separate compilation.  You put your list code ecListFuncs.cpp
 *  Code in this file should call those functions.
 */


#include <iostream>
#include <string>

// for istringstream used in buildList (defined below)
#include <sstream>

#include "ecListFuncs.h"

using namespace std;


// You may use the following two utility functions that will make it easier to
// test your list functions on hard-coded list data and compare it to expected
// output:
// (function definitions for them appear at the bottom of this file)


/*
 * listToString
 *
 * PRE: list is a well-formed list.
 *
 * converts the list to a string form that has the following format shown by example.
 * the list is unchanged by the function.
 *
 *   string format:
 *
 *   "()"        an empty list
 *   "(3)        a list with one element, 3
 *   "(3 4 5)"   a list with multiple elements: 3 followed by 4 followed by 5
 *
 */
string listToString(ListType list);


/*
 * buildList
 * 
 * PRE: listString only contains numbers (valid integer format) and spaces
 *
 * creates and returns a linked list from a string of space separated numbers
 * 
 *
 * Examples:
 *  listString         return value of buildList(listString)
 *
 *    ""               ()
 *    "-32"            (-32)
 *    "     -32   "    (-32)
 *    "1 3 2"          (1 3 2)
 *    "  1 3 2"        (1 3 2)
 *
 */
ListType buildList(const string & listString);

bool equalList(ListType a, ListType b);

void numAdjDupesTester(string input, int expect);

void removeDivTester(string input, int k, string expect);

void splitAtLocTester(string input, int index, string expect1, string expect2, string expect3 );


int main ()
{
   cout << "Test numAdjDupes()" << endl;
   numAdjDupesTester("", 0);
   numAdjDupesTester("2 8 3", 0);
   numAdjDupesTester("4 4 7 3", 1);
   numAdjDupesTester("5 5 7 5 5 5 5",2);
   numAdjDupesTester("5 7 5 7",0);
   numAdjDupesTester("5 5 5 3 3 3 4 4 4 4",3);
   cout << "Test removeDiv()" << endl;
   removeDivTester("", 3, "()");
   removeDivTester("7 10", 3, "(7 10)");
   removeDivTester("24 12 6 9", 4, "(6 9)");
   removeDivTester("24 12 6 9", 3, "()");
   removeDivTester("3 2 8 4 7", 2, "(3 7)");
   removeDivTester("1 2 3 4 5", 1, "()");
   cout << "Test splitAtLoc()" << endl;
   splitAtLocTester("7 4 4 3 9", 2, "(7 4)", "(3 9)", "()");
   splitAtLocTester("7 4 2 3 9", 0, "()", "(4 2 3 9)", "()");
   splitAtLocTester("1 2 3 3 2", 4, "(1 2 3 3)", "()", "()");
   splitAtLocTester("", 3, "()", "()", "()");
   splitAtLocTester("8 2 5", 2, "(8 2)", "()", "()");
   splitAtLocTester("8 2 5", 3, "(8 2 5)", "()", "()");
   splitAtLocTester("8 2 5", -3, "()", "(8 2 5)", "()");
   splitAtLocTester("3", 0, "()", "()", "()");
   splitAtLocTester("3 5", 0, "()", "(5)", "()");
   splitAtLocTester("3 5", 1, "(3)", "()", "()");
   return 0;
}


/*********************************************************
 * Utility function definitions
 *
 */
string listToString(ListType list) {

   string listString = "(";

   if (list == NULL) {
      listString += ")";
      return listString;
   }

   Node *p = list;
   while (p->next != NULL) {
      listString += to_string(p->data) + " ";
      p = p->next;
   }

   // print last one with no trailing space
   listString += to_string(p->data) + ")";

   return listString;

}   


ListType buildList(const string & listString) {

   ListType nums = NULL;

   istringstream istr(listString);  // similar to a Java Scanner over a String

   int num;

   if (istr >> num) { // is there one value there?
      nums = new Node(num);
   }
   else {
      return NULL;
   }

   Node *last = nums;

   while (istr >> num) { 
      last->next = new Node(num);
      last = last->next;
   }

   return nums;
}

bool equalList(ListType a, ListType b) {
   string strA = listToString(a);
   string strB = listToString(b);
   return strA == strB;
}

void numAdjDupesTester(string input, int expect) {
   ListType list = buildList(input);
   int res = numAdjDupes(list);
   string pass = "failed";
   if (res==expect) {
      pass = "passed";
   }
   cout << "Input: " << input << " Output: " << res << " Expected: " << expect << " Pass: " << pass << endl;
}

void removeDivTester(string input, int k, string expect) {
   ListType list = buildList(input);
   removeDiv(list, k);
   string res = listToString(list);
   string pass = "failed";
   if (res==expect) {
      pass = "passed";
   }
   cout << "Input: list " << input << " k: " << k << " Output: " << res << " Expected: " << expect << " Pass: " << pass << endl;
}

void splitAtLocTester(string input, int index, string expect1, string expect2, string expect3 ) {
   ListType list = buildList(input);
   ListType a = NULL;
   ListType b = NULL;
   splitAtLoc(list, index, a, b);
   string res1 = listToString(a);
   string res2 = listToString(b);
   string pass = "failed";
   if (res1==expect1 && res2==expect2 && listToString(list)==expect3) {
      pass = "passed";
   }
   cout << "Input: list " << input << " index: " << index << " Output: " << res1 << "; " << res2 << "; " << listToString(list) << " Expected: " << expect1  << "; " << expect2 << "; " << expect3 << " Pass: " << pass << endl;

}